package com.example.ambulance_app_v1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
