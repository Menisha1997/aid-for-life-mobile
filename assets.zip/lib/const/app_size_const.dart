class AppSize {
  static const double DEFAULT_SPACE = 10.0;
  static const double DEFAULT_PADDING = 48.0;
  static const double DEFAULT_RADIUS = 12.0;
}
