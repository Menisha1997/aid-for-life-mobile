class AppImage {
  static String LOGO = "assets/images/logo.png";
  static String LOGIN_ICON = "assets/images/login-img.png";
}
