library globals;

import 'models/app_user_model.dart';

AppUser currentUser = AppUser();
