import 'package:ambulance_app_v1/const/app_image_const.dart';
import 'package:ambulance_app_v1/const/app_size_const.dart';
import 'package:ambulance_app_v1/views/auth/signup_screen.dart';
import 'package:ambulance_app_v1/views/dashboard/home_page.dart';
import 'package:ambulance_app_v1/widgets/custom_button_widget.dart';
import 'package:ambulance_app_v1/widgets/custom_paint_widget.dart';
import 'package:ambulance_app_v1/widgets/custom_text_form_field_widget.dart';
import 'package:flutter/material.dart';

import 'Call_page.dart';
import 'blood_group_list.dart';
import 'firstaid_page.dart';
import 'map_page.dart';

class Firstaid extends StatefulWidget {
  const Firstaid({Key? key}) : super(key: key);

  @override
  _FirstaidState createState() => _FirstaidState();
}

class _FirstaidState extends State<Firstaid> {
  int _currentIndex = 0;
  final List<Widget> _children = [
    Call_page(),
    Call_page(),
    Firstaid(),
    BloodGroupList(),
    Firstaid(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomPaint(
        size: MediaQuery.of(context).size,
        painter: BackGroundPainter(context),
        child: Padding(
          padding: EdgeInsets.fromLTRB(50, 190, 70, 50),
          child: ListView(
            padding: const EdgeInsets.all(8),
            children: <Widget>[
              Text(
                "Find Your Doner",
                style: TextStyle(
                  color: Color.fromARGB(255, 6, 97, 6),
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              ListTile(
                onTap: () => {},
                title: Text("Hyperglysimia"),
                subtitle: Text("High Suger level."),
                leading: Icon(Icons.emergency),
              ),
              ListTile(
                title: Text("Hypoglysimia"),
                subtitle: Text("Low Suger level."),
                leading: Icon(Icons.emergency),
                onTap: () => {},
              ),
              ListTile(
                title: Text("Hypertention"),
                subtitle: Text("High BP."),
                leading: Icon(Icons.emergency),
                onTap: () => {},
              ),
              ListTile(
                title: Text("Hypotention"),
                subtitle: Text("Low BP."),
                leading: Icon(Icons.emergency),
                onTap: () => {},
              ),
              ListTile(
                title: Text("Hypovolimia"),
                subtitle: Text("Low Water Level"),
                leading: Icon(Icons.emergency),
                onTap: () => {},
              ),
              ListTile(
                title: Text("O Negatve  O-"),
                subtitle: Text("O- Doners."),
                leading: Icon(Icons.emergency),
                onTap: () => {},
              ),
              ListTile(
                title: Text("AB Positive  AB+"),
                subtitle: Text("AB+ Doners."),
                leading: Icon(Icons.emergency),
                onTap: () => {},
              ),
              ListTile(
                title: Text("AB Negatve  AB-"),
                subtitle: Text("AB- Doners."),
                leading: Icon(Icons.emergency),
                onTap: () => {},
              ),
            ],
          ),
        ),
      ),
    );
  }

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }
}
