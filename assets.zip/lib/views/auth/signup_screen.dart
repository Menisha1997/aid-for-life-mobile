import 'package:ambulance_app_v1/const/app_image_const.dart';
import 'package:ambulance_app_v1/const/app_size_const.dart';
import 'package:ambulance_app_v1/views/auth/signin_screen.dart';
import 'package:ambulance_app_v1/widgets/custom_button_widget.dart';
import 'package:ambulance_app_v1/widgets/custom_paint_widget.dart';
import 'package:ambulance_app_v1/widgets/custom_text_form_field_widget.dart';
import 'package:flutter/material.dart';

import '../../widgets/progress_HUD.dart';

class SignUp extends StatefulWidget {
  const SignUp({Key? key}) : super(key: key);

  @override
  _SignUpState createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  final GlobalKey<FormState> _formKey = GlobalKey();
  bool _isAPICallProcess = false;

  final TextEditingController _email = TextEditingController();
  final TextEditingController _password = TextEditingController();

  final TextEditingController _fullname = TextEditingController();
  final TextEditingController _nic = TextEditingController();
  final TextEditingController _phone = TextEditingController();
  final TextEditingController _dob = TextEditingController();
  final TextEditingController _gender = TextEditingController();
  final TextEditingController _bloodGroup = TextEditingController();

  void signUp() {}

  @override
  Widget build(BuildContext context) {
    return ProgressHUD(
      inAsyncCall: _isAPICallProcess,
      child: Scaffold(
        body: CustomPaint(
          size: MediaQuery.of(context).size,
          painter: BackGroundPainter(context),
          child: Padding(
            // ignore: prefer_const_constructors
            padding: const EdgeInsets.all(AppSize.DEFAULT_PADDING),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  Image.asset(
                    AppImage.LOGIN_ICON,
                    height: 60,
                  ),

                  // login box
                  const SizedBox(
                    height: 05,
                  ),

                  const Text(
                    "Sign Up",
                    style: TextStyle(
                      decoration: TextDecoration.underline,
                      fontSize: 20,
                    ),
                  ),

                  CustomTextFormField(
                    controller: _fullname,
                    label: "Full Name",
                    type: TextInputType.text,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Enter a valid full name';
                      }
                      return null;
                    },
                  ),
                  CustomTextFormField(
                    controller: _nic,
                    label: "NIC",
                    type: TextInputType.text,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Enter a valid NIC';
                      }
                      return null;
                    },
                  ),
                  CustomTextFormField(
                    controller: _phone,
                    label: "Ph-No",
                    type: TextInputType.number,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Enter a valid phone';
                      }
                      return null;
                    },
                  ),
                  CustomTextFormField(
                    controller: _dob,
                    label: "DateOfBirth",
                    type: TextInputType.text,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Enter a valid full name';
                      }
                      return null;
                    },
                  ),
                  CustomTextFormField(
                    controller: _gender,
                    label: "Gender",
                    type: TextInputType.text,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Enter a valid full name';
                      }
                      return null;
                    },
                  ),
                  CustomTextFormField(
                    controller: _bloodGroup,
                    label: "Blood Group",
                    type: TextInputType.text,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Enter a valid full name';
                      }
                      return null;
                    },
                  ),

                  CustomTextFormField(
                    controller: _email,
                    label: "Email",
                    type: TextInputType.emailAddress,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Enter a valid full name';
                      }
                      return null;
                    },
                  ),
                  CustomFormPasswordField(
                    controller: _password,
                    label: "Password",
                    type: TextInputType.text,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Enter a valid full name';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  CustomButton(
                    lable: "Sign in",
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => const SignIn()));
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
